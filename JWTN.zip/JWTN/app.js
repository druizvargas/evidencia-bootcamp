const express = require('express');
const app = express();
const jwt = require('jsonwebtoken');
const Keys = require('./Config/Keys');

app.set('key',Keys.key);
app.use(express.urlencoded({extended : false}));
app.use(express.json());

app.post('/login', (req, res) =>{
   if(req.body.usuario == 'admin' && req.body.pass == 'asd1234'){
    const payload = {
        check: true
    };
    const token = jwt.sign(payload, app.get('key'), {
        expiresIn: '3d'
    });
    res.json({msg: "se encuentra logueado con el login", token: token})

   }else{
    res.json({msg: "el usuario y contraseña no son correctos"});

   }

});

const verificacion = express.Router();

verificacion.use((req, res, next) => {
let token = req.headers['acces-token'] || req.headers['authorization'];
//console.log(token);



if(!token){
    res.status(401).send({ msg:"token no valido, pude estar sin token"});
    return
}

if(token.startsWith('Bearer')){
    token = token.slice(7, token.length);
    console.log(token);
}
if(token){
    jwt.verify(token,app.get('key'), (error, decoded) => {
    if(error){
        return res.json({msg: "El token enviado no es correcto"});

    }else{
        req.decoded = decoded;
        next();
    }
    });
}


});






app.get('/info', verificacion,(req, res) =>{
res.json('Ingreo exitoso al modulo');   
});




















//configuracion del servidor por el puerto 5000
app.listen(5000, ()=> {
    console.log('el servidor esta conectado http://localhost:5000');
});   

// configuracion app.get para ver el mensaje en el navegador
app.get('/',(req, res)=>{
    res.send('Hola mundo');
});